namespace Simple_Punch_Out_Game_MOO_ICT
{
    public partial class Form1 : Form
    {
        bool playerBlock = false;
        bool enemyBlock = false;
        Random random = new Random();
        int enemySpeed = 5;
        int index = 0;
        int playerHealth = 100;
        int enemyHealth = 300;
        int comboCount = 0;
        int score = 0;
        List<string> enemyAttack = new List<string> { "left", "right", "block" };

        public Form1()
        {
            InitializeComponent();
            ResetGame();
        }

        private void BoxerAttackTImerEvent(object sender, EventArgs e)
{
    index = random.Next(0, enemyAttack.Count);
    // Optional: Play a sound effect for enemy attack
    PlaySound("attack");

    // Verifique se o inimigo est� ferido
    bool isEnemyInjured = enemyHealth < 100;

    switch (enemyAttack[index])
    {
        case "left":
            boxer.Image = isEnemyInjured ? Properties.Resources.enemy_punch1_ferido : Properties.Resources.enemy_punch1;
            enemyBlock = false;

            if (boxer.Bounds.IntersectsWith(player.Bounds) && !playerBlock)
            {
                playerHealth -= 5;
            }
            break;

        case "right":
            boxer.Image = isEnemyInjured ? Properties.Resources.enemy_punch2_ferido : Properties.Resources.enemy_punch2;
            enemyBlock = false;

            if (boxer.Bounds.IntersectsWith(player.Bounds) && !playerBlock)
            {
                playerHealth -= 5;
            }
            break;

        case "block":
            boxer.Image = isEnemyInjured ? Properties.Resources.enemy_block_ferido : Properties.Resources.enemy_block;
            enemyBlock = true;
            break;
    }

    // Special attack after certain conditions
    if (enemyHealth < 50 && random.Next(0, 10) < 2) // 20% chance to perform special attack
    {
        PerformSpecialAttack();
    }
}


        private void PerformSpecialAttack()
        {
            boxer.Image = Properties.Resources.enemy_special_attack;
            // Optional: Play special attack sound
            PlaySound("special_attack");

            if (boxer.Bounds.IntersectsWith(player.Bounds) && !playerBlock)
            {
                playerHealth -= 20; // Deal more damage
            }
        }

        private void BoxerMoveTimerEvent(object sender, EventArgs e)
        {
            // Update health bars
            UpdateHealthBars();

            // Move the boxer
            boxer.Left += enemySpeed;

            if (boxer.Left > 430) enemySpeed = -5;
            if (boxer.Left < 220) enemySpeed = 5;

            // Check for end game scenario
            CheckGameEnd();
        }

        private void UpdateHealthBars()
        {
            playerHealthBar.Maximum = 100; // M�ximo para a barra do jogador
            boxerHealthBar.Maximum = 300;   // M�ximo para a barra do inimigo

            // Garantir que a vida n�o fique abaixo de 0
            playerHealthBar.Value = Math.Max(0, Math.Min(100, playerHealth));
            boxerHealthBar.Value = Math.Max(0, Math.Min(300, enemyHealth));
        }

        private void CheckGameEnd()
        {
            if (enemyHealth < 1)
            {
                EndGame("You Win! Your Score: " + score);
            }
            else if (playerHealth < 1)
            {
                EndGame("Tough Rob Wins! Your Score: " + score);
            }
        }

        private void EndGame(string message)
        {
            BoxerAttackTimer.Stop();
            BoxerMoveTimer.Stop();
            MessageBox.Show(message + " Click OK to Play Again", "Moo Says: ");
            ResetGame();
        }

        private void KeyIsDown(object sender, KeyEventArgs e)
        {
            // Handle player attacks
            if (e.KeyCode == Keys.Left || e.KeyCode == Keys.Right)
            {
                HandlePlayerAttack(e.KeyCode);
            }
            if (e.KeyCode == Keys.Down)
            {
                player.Image = Properties.Resources.boxer_block;
                playerBlock = true;
            }
        }

        private void HandlePlayerAttack(Keys key)
        {
            player.Image = key == Keys.Left ? Properties.Resources.boxer_left_punch : Properties.Resources.boxer_right_punch;
            playerBlock = false;

            if (player.Bounds.IntersectsWith(boxer.Bounds) && !enemyBlock)
            {
                enemyHealth -= 5;
                score += 10; // Increment score for successful hits
                comboCount++;
                // Optional: Check for combo
                if (comboCount >= 3)
                {
                    // Perform a special combo move
                    enemyHealth -= 10; // Extra damage for combo
                    comboCount = 0; // Reset combo count
                }
            }
        }

        private void KeyIsUp(object sender, KeyEventArgs e)
        {
            player.Image = Properties.Resources.boxer_stand; // Imagem padr�o do jogador
            playerBlock = false;

            // Verifique se a tecla pressionada foi a seta para cima
            if (e.KeyCode == Keys.Up)
            {
                // Verifique se o inimigo tem 150 ou menos de vida antes de realizar o ataque especial
                if (enemyHealth <= 150)
                {
                    PerformSpecialAttack2(); // Chame o m�todo para o ataque especial
                }
            }
        }

        private void PerformSpecialAttack2()
        {
            player.Image = Properties.Resources.boxer_special_attack; // Define a imagem do ataque especial
            PlaySound("special_attack"); // Opcional: toque um som para o ataque especial

            // Danifique o inimigo se o ataque especial atinge
            if (boxer.Bounds.IntersectsWith(player.Bounds) && !enemyBlock)
            {
                enemyHealth -= 30; // Dano maior para o ataque especial
                score += 20; // Aumenta a pontua��o para o ataque especial
            }

            // Atualiza a barra de sa�de
            UpdateHealthBars();
        }


        private void ResetGame()
        {
            BoxerAttackTimer.Start();
            BoxerMoveTimer.Start();
            playerHealth = 100;
            enemyHealth = 300;
            score = 0; // Reset score
            comboCount = 0; // Reset combo count
            boxer.Left = 400;
        }

        private void PlaySound(string soundName)
        {
            // Logic to play sound based on the sound name
            // You can use a library like System.Media or NAudio to play sounds
        }
    }
}
